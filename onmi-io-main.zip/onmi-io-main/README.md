# Ambil Api_key  
```https://rapidapi.com/eaidoo015-pj8dZiAnLJJ/api/temp-mail94```
